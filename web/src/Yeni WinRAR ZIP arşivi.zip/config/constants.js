// src/config/constants.js
export const API_URL = "http://localhost:3000";

export const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#FF4D4F"];
